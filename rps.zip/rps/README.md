# RPS

A Pen created on CodePen.

Original URL: [https://codepen.io/Damilola-Olonitola/pen/yyBdrwZ](https://codepen.io/Damilola-Olonitola/pen/yyBdrwZ).

